//
//  EduskuntaFromWebTests.swift
//  EduskuntaFromWebTests
//
//  Created by Mika Grönroos on 3.3.2025.
//

import Testing
@testable import EduskuntaFromWeb

struct EduskuntaFromWebTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
