//
//  EduskuntaOnTheMapTests.swift
//  EduskuntaOnTheMapTests
//
//  Created by Mika Grönroos on 7.3.2025.
//

import Testing
@testable import EduskuntaOnTheMap

struct EduskuntaOnTheMapTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
